<?php


namespace IPS\wkmygosl\modules\admin\settings;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * settings
 */
class _settings extends \IPS\Dispatcher\Controller
{
	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		$this->app = \IPS\Application::load('wkmygosl');
		parent::execute();
	}

	/**
	 * ...
	 *
	 * @return	void
	 */
	protected function manage()
	{
		$form = new \IPS\Helpers\Form;
		
		$form->addTab('wkMyGoSL_general');
		$form->add( new \IPS\Helpers\Form\Number( 'wkMyGoSL_userId', \IPS\Settings::i()->wkMyGoSL_userId, TRUE, [ 'decimals' => FALSE, 'min' => 0 ] ) );
		$form->add( new \IPS\Helpers\Form\YesNo( 'wkMyGoSL_enabled', \IPS\Settings::i()->wkMyGoSL_enabled ) );
		$form->add( new \IPS\Helpers\Form\Select( 'wkMyGoSL_whoView', \IPS\Settings::i()->wkMyGoSL_whoView != '*' ? explode( ',', \IPS\Settings::i()->wkMyGoSL_whoView ) : '*', FALSE, [ 'options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'all_groups' ], NULL, NULL, NULL, 'wkMyGoSL_whoView' ) );
		
		$form->addTab('wkMyGoSL_other');
		$form->add( new \IPS\Helpers\Form\Color( 'wkMyGoSL_colors1', \IPS\Settings::i()->wkMyGoSL_colors1, FALSE, [], NULL, NULL, NULL, 'wkMyGoSL_colors1' ) );
		$form->add( new \IPS\Helpers\Form\Color( 'wkMyGoSL_colors2', \IPS\Settings::i()->wkMyGoSL_colors2, FALSE, [], NULL, NULL, NULL, 'wkMyGoSL_colors2' ) );
		$form->add( new \IPS\Helpers\Form\Color( 'wkMyGoSL_colors3', \IPS\Settings::i()->wkMyGoSL_colors3, FALSE, [], NULL, NULL, NULL, 'wkMyGoSL_colors3' ) );
		$form->add( new \IPS\Helpers\Form\Color( 'wkMyGoSL_colors4', \IPS\Settings::i()->wkMyGoSL_colors4, FALSE, [], NULL, NULL, NULL, 'wkMyGoSL_colors4' ) );
		$form->add( new \IPS\Helpers\Form\Color( 'wkMyGoSL_colors5', \IPS\Settings::i()->wkMyGoSL_colors5, FALSE, [], NULL, NULL, NULL, 'wkMyGoSL_colors5' ) );
		$form->add( new \IPS\Helpers\Form\Color( 'wkMyGoSL_colors6', \IPS\Settings::i()->wkMyGoSL_colors6, FALSE, [], NULL, NULL, NULL, 'wkMyGoSL_colors6' ) );
		
		if ( $values = $form->values( TRUE ) )
		{
			$form->saveAsSettings();
		}
		
		\IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('settings');
		\IPS\Output::i()->output = $form . $this->app->authorFooter(0);
	}
}