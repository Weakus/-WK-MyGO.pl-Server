<?php
/**
 * @brief		mygosl Widget
 * @author		<a href='https://www.invisioncommunity.com'>Invision Power Services, Inc.</a>
 * @copyright	(c) Invision Power Services, Inc.
 * @license		https://www.invisioncommunity.com/legal/standards/
 * @package		Invision Community
 * @subpackage	wkmygosl
 * @since		13 Mar 2020
 */

namespace IPS\wkmygosl\widgets;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * mygosl Widget
 */
class _mygosl extends \IPS\Widget\StaticCache
{
	/**
	 * @brief	Widget Key
	 */
	public $key = 'mygosl';
	
	/**
	 * @brief	App
	 */
	public $app = 'wkmygosl';
		
	/**
	 * @brief	Plugin
	 */
	public $plugin = '';
	
	/**
	 * Initialise this widget
	 *
	 * @return void
	 */ 
	public function init()
	{
		$this->template( [ \IPS\Theme::i()->getTemplate( 'widgets', $this->app, 'front' ), $this->key ] );
		$this->language = \IPS\Member::loggedIn()->language();
		
		\IPS\Output::i()->cssFiles = array_merge(\IPS\Output::i()->cssFiles, \IPS\Theme::i()->css( 'wkmygosl.css', 'wkmygosl', 'front'));
		
		parent::init();
	}
	
	/**
	 * Specify widget configuration
	 *
	 * @param	null|\IPS\Helpers\Form	$form	Form object
	 * @return	null|\IPS\Helpers\Form
	 */
	public function configuration( &$form=null )
	{
 		$form = parent::configuration( $form );

 		return $form;
 	} 
 	
 	 /**
 	 * Ran before saving widget configuration
 	 *
 	 * @param	array	$values	Values from form
 	 * @return	array
 	 */
 	public function preConfig( $values )
 	{
 		return $values;
 	}

	/**
	 * Render a widget
	 *
	 * @return	string
	 */
	public function render()
	{
		if( $this->application()->can_View() || $this->application()->_userIdVer() == 0 )
		{
			return "";
		}
		
		$date = [];
		
		try
		{
			foreach( $this->application()->userId( \IPS\Settings::i()->wkMyGoSL_userId ) as $row )
			{
				$row['serverPlayers'] = [ 'players' => $row['serverPlayers'] ];
				$row['serverUrls']	= $this->application()->serverUrls( $row['serverId'] );
			
				try
				{
					$row['serverPercent'] = number_format($row['serverMin'] / $row['serverMax'] * 100, 2, '.', '.');
				}
				catch ( \Exception $e )
				{
					$row['serverPercent'] = 0;
				}
			
				if($row['serverPercent'] < 20)
				{
					$row['serverPercentColor'] = \IPS\Settings::i()->wkMyGoSL_colors1;
				}
				elseif($row['serverPercent'] >= 20 AND $row['serverPercent'] < 40)
				{
					$row['serverPercentColor'] = \IPS\Settings::i()->wkMyGoSL_colors2;
				}
				elseif($row['serverPercent'] >= 40 AND $row['serverPercent'] < 60)
				{
					$row['serverPercentColor'] = \IPS\Settings::i()->wkMyGoSL_colors3;
				}
				elseif($row['serverPercent'] >= 60 AND $row['serverPercent'] < 80)
				{
					$row['serverPercentColor'] = \IPS\Settings::i()->wkMyGoSL_colors4;
				}
				elseif($row['serverPercent'] >= 80 AND $row['serverPercent'] < 100)
				{
					$row['serverPercentColor'] = \IPS\Settings::i()->wkMyGoSL_colors5;
				}
				else
				{
					$row['serverPercent'] = 100;
					$row['serverPercentColor'] = \IPS\Settings::i()->wkMyGoSL_colors6;
				}
			
				$totalPlayers += $row['serverMin']; $totalSlots += $row['serverMax'];
			
				$sumStats = [
					'totalServers'	=> $this->language->formatNumber(\count($date) +1),
					'totalPlayers'	=> $this->language->formatNumber(array_sum(array_map(function($var) { return $var['serverMin']; }, $date))),
					'totalSlots'	=> $this->language->formatNumber(array_sum(array_map(function($var) { return $var['serverMax']; }, $date))),
					'totalViews'	=> $this->language->formatNumber(array_sum(array_map(function($var) { return $var['serverViews']; }, $date))),
					'totalMost'		=> $this->language->formatNumber(array_sum(array_map(function($var) { return $var['serverPlayers']['players']['dataMost']['numPlayers']; }, $date))),
					'totalPercent'	=> number_format($totalPlayers / $totalSlots * 100, 2, '.', '.'),
				];
			
				$date[] = $row;
			}
		}
		catch ( \Exception $e ){}
		
		return \count($date) ? $this->output($date, $sumStats) . $this->application()->authorFooter(1) : "";
	}
}