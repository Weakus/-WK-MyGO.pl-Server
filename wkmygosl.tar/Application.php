<?php
/**
 * @brief		(WK) MyGO.pl Server List Application Class
 * @author		<a href='https://steamcommunity.com/id/WeakLove/'>Weak.</a>
 * @copyright	(c) 2020 Weak.
 * @package		Invision Community
 * @subpackage	(WK) MyGO.pl Server List
 * @since		12 Mar 2020
 * @version		
 */
 
namespace IPS\wkmygosl;

/**
 * (WK) MyGO.pl Server List Application Class
 */
class _Application extends \IPS\Application
{
	public function __construct()
	{
		$this->date = new \IPS\DateTime;
		$this->dateClone = clone $this->date;
	}
	
	protected function get__icon()
	{
		return 'list';
	}
	
	public function can_View()
	{
		return ( !\IPS\Settings::i()->wkMyGoSL_enabled OR ( \IPS\Settings::i()->wkMyGoSL_whoView != '*' AND !\IPS\Member::loggedIn()->inGroup( explode( ',', \IPS\Settings::i()->wkMyGoSL_whoView ) ) ) ) ? 1 : 0;
	}
	
	public function _userIdVer()
	{
		return ( \IPS\Settings::i()->wkMyGoSL_userId != 0 ) ? 1 : 0;
	}
	
	public function getTimeMin($time)
	{
		$today = clone $this->date;
		return \IPS\DateTime::formatInterval($this->date->diff($today->modify('+'.round($time).' seconds')), 0);
	}
	
	public function userId($userId)
	{
		$jsonDate = "https://mygo.pl/applications/wkmygoservers/interface/api/?id={$userId}";
		return json_decode(file_get_contents($jsonDate), TRUE);
	}
	
	public function serverUrls($serverUrls)
	{
		$date = "https://mygo.pl/servers/view-{$serverUrls}/";
		return $date;
	}
	
	public function authorFooter($footerType = 1)
	{
		$return = [];
		
		if($footerType == 0)
		{
			$return[] = "<div class='ipsPos_right ipsClear' style='margin: 10px;'>";
			$return[] = "<strong>ServerList</strong> by <a href='{$this->website}' target='_blank'>{$this->author}</a> & <a href='https://mygo.pl/' target='_blank' title='MyGo.pl - Forum CS & Support SourceMod'>MyGo.pl</a>";
			$return[] = "</div>";
		}
		else
		{
			$return = [];
			$return[] = "<div class='ipsPos_right ipsClear'  style='margin: 5px;font-size: 12px;' >";
			$return[] = "<span title='MyGo.pl - Forum CS & Support SourceMod'><strong>ServerList</strong> by <a href='https://mygo.pl/' target='_blank'>MyGo.pl</a></span>";
			$return[] = "</div>";
		}
		
		return implode(' ', $return);
	}
}